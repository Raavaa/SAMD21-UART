/*
 * DeviceUSART.c
 *
 * Created: 11/9/2020 9:50:50 AM
 * Author : Daved
 */ 


#include "sam.h"
#include "hal_gpio.h"
#include "gpio.h"
#include "tmr.h"
#include "stdbool.h"
#include "stdlib.h"
#include "stdlib.h"

// Definitions 
#define UART_SERCOM							SERCOM0
#define UART_SERCOM_CLK_GEN					0
#define UART_SERCOM_GCLK_ID					SERCOM0_GCLK_ID_CORE
#define UART_SERCOM_APBCMASK				PM_APBCMASK_SERCOM0


#define F_CPU		8000000

//HAL_GPIO_PIN(UART_TX,	A,	6) // Pin setup for LTM module
//HAL_GPIO_PIN(UART_RX,	A,	5)

HAL_GPIO_PIN(UART_TX,	B,	30)
HAL_GPIO_PIN(UART_RX,	B,	31)



/*static void uart_init(uint32_t baud) //uart init for LTM module
{
	uint64_t baudrate = (uint64_t)65536 * (F_CPU - 16 * baud) / F_CPU;

	HAL_GPIO_UART_TX_out();
	HAL_GPIO_UART_TX_pmuxen(PORT_PMUX_PMUXE_C_Val);
	HAL_GPIO_UART_RX_in();
	HAL_GPIO_UART_RX_pmuxen(PORT_PMUX_PMUXE_C_Val);

	PM->APBCMASK.reg |= PM_APBCMASK_SERCOM0;

	GCLK->CLKCTRL.reg = GCLK_CLKCTRL_ID(SERCOM0_GCLK_ID_CORE) |
	GCLK_CLKCTRL_CLKEN | GCLK_CLKCTRL_GEN(0);

	UART_SERCOM->USART.CTRLA.reg =
	SERCOM_USART_CTRLA_DORD | SERCOM_USART_CTRLA_MODE_USART_INT_CLK |
	SERCOM_USART_CTRLA_RXPO(0x1) | SERCOM_USART_CTRLA_TXPO(0x1);

	UART_SERCOM->USART.CTRLB.reg = SERCOM_USART_CTRLB_RXEN | SERCOM_USART_CTRLB_TXEN |
	SERCOM_USART_CTRLB_CHSIZE(0);

	UART_SERCOM->USART.BAUD.reg = (uint16_t)baudrate+1;

	UART_SERCOM->USART.CTRLA.reg |= SERCOM_USART_CTRLA_ENABLE;
}*/

static void uart_init2(uint32_t baud) // Uart init for SERCOM 5 pins
{
	uint64_t br = (uint64_t)65536 * (8000000 - 16 * baud) / 8000000;

	HAL_GPIO_UART_TX_out();
	HAL_GPIO_UART_TX_pmuxen(PORT_PMUX_PMUXE_D_Val);
	HAL_GPIO_UART_RX_in();
	HAL_GPIO_UART_RX_pmuxen(PORT_PMUX_PMUXE_D_Val);

	PM->APBCMASK.reg |= PM_APBCMASK_SERCOM5;

	GCLK->CLKCTRL.reg = GCLK_CLKCTRL_ID(SERCOM5_GCLK_ID_CORE) |
	GCLK_CLKCTRL_CLKEN | GCLK_CLKCTRL_GEN(0);

	SERCOM5->USART.CTRLA.reg =
	SERCOM_USART_CTRLA_DORD | SERCOM_USART_CTRLA_MODE_USART_INT_CLK |
	SERCOM_USART_CTRLA_RXPO(0x1) | SERCOM_USART_CTRLA_TXPO(0x0);

	SERCOM5->USART.CTRLB.reg = SERCOM_USART_CTRLB_RXEN | SERCOM_USART_CTRLB_TXEN |
	SERCOM_USART_CTRLB_CHSIZE(0/*8 bits*/);

	SERCOM5->USART.BAUD.reg = (uint16_t)br+1;

	SERCOM5->USART.CTRLA.reg |= SERCOM_USART_CTRLA_ENABLE;
}


static void sys_init(void)
{
	// Switch to 8MHz clock (disable prescaler)
	SYSCTRL->OSC8M.bit.PRESC = 0;
}

/*static void uart_putc(char c) // PUTC for LTM setup
{
	while (!(UART_SERCOM->USART.INTFLAG.reg & SERCOM_USART_INTFLAG_DRE));
	SERCOM0->USART.DATA.reg = c;
}*/

static void uart_putc(char c)
{
	while (!(SERCOM5->USART.INTFLAG.reg & SERCOM_USART_INTFLAG_DRE));
	SERCOM5->USART.DATA.reg = c;
}

static void uart_puts(char *s)
{
	while (*s)
	uart_putc(*s++);
}

void toggle(void)
{
	Toggle_output();
	Toggle_LOW();
	// delay(2000);
	Toggle_input();
}


int main(void)
{
	//SystemInit();
	sys_init();
	GPIO_Init();
	TMR_Init();
	
	//toggle(); // initialization for LTM communication
	//LTM_HIGH(); // initialization for LTM communication
	//TX_HIGH(); // initialization for LTM communication
	
	uart_init2(115200);
	
	uart_puts("U");
	
    
    while (1) 
    {
			//uart_puts("hello world");

    }
}
